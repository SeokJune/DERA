# WeatherForecast_LSJ.py
#  Title: Weather Forecast
# AUTHOR: LEE SEOKJUNE
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import sklearn.metrics as metrics 

# 전처리 된 데이터 가져오기
Weather = pd.read_csv('../Data/pWeather2.csv', encoding='euc-kr')

# 데이터의 행 갯수
rows = len(Weather)
#rows = int(rows_ * 0.05 * 4)

# 데이터의 열 정보
'''
03-평균기온(°C)		04-최저기온(°C)		05-최고기온(°C)
06-일강수량(mm)			07-평균 이슬점온도(°C)		08-최소 상대습도(%)
09-평균 상대습도(%)		10-평균 증기압(hPa)		11-평균 현지기압(hPa)
12-최고 해면기압(hPa)		13-최저 해면기압(hPa)		14-평균 해면기압(hPa)
15-가조시간(hr)			16-합계 일조시간(hr)		17-합계 일사량(MJ/m2)
18-일 최심신적설(cm)		19-일 최심적설(cm)		20-평균 전운량(1/10)
21-평균 중하층운량(1/10)	22-평균 지면온도(°C)		23-최저 초상온도(°C)
'''
cols = [3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23]

# 반복 횟수
count = 1

# 램덤포레스트 매개변수
n_estimators_ = 10
max_features_ = 'auto'
min_samples_leaf_ = 1
max_leaf_nodes_ = None
max_depth_ = None

# 결과 반환 리스트
result = []
    
# 데이터를 Train, Test 데이터로 분할
X_train, X_test, Y_train, Y_test = train_test_split(Weather.iloc[:rows,cols],
                                                    Weather.iloc[:rows,-1:],
                                                    test_size = 0.2)
for cnt in range(1, 101):
    min_samples_leaf_ = cnt
    print(min_samples_leaf_)
    # 랜덤포레스트 객체 생성
    rfc = RandomForestClassifier(n_estimators = n_estimators_,
                                 max_features = max_features_,
                                 min_samples_leaf = min_samples_leaf_,
                                 max_leaf_nodes = max_leaf_nodes_,
                                 max_depth = max_depth_             # 깊이(과대적합 감소)
                                 )

    rfc.fit(X_train, Y_train.values.ravel())


    for cnt in range(0, count):
        # 스코어 저장 리스트
        train_result1 = []
        train_result2 = []
        train_result3 = []
        train_result4 = []
        test_result1 = []
        test_result2 = []
        test_result3 = []
        test_result4 = []
        # 훈련
        rfc.fit(X_train, Y_train.values.ravel())
        # train과 test에 해당하는 예측결과
        trainPred = rfc.predict(X_train)
        testPred = rfc.predict(X_test)
        #
        train_result1.append(metrics.accuracy_score(Y_train, trainPred))
        train_result2.append(metrics.precision_score(Y_train, trainPred))
        train_result3.append(metrics.recall_score(Y_train, trainPred))
        train_result4.append(metrics.f1_score(Y_train, trainPred))

        test_result1.append(metrics.accuracy_score(Y_test, testPred))
        test_result2.append(metrics.precision_score(Y_test, testPred))
        test_result3.append(metrics.recall_score(Y_test, testPred))
        test_result4.append(metrics.f1_score(Y_test, testPred))

    # 평균
    result.append(['LSJ', cols, rows, count,
                   n_estimators_, max_features_, min_samples_leaf_, max_leaf_nodes_, max_depth_,
                   round(sum(train_result1) / len(train_result1),3),
                   round(sum(train_result2) / len(train_result2),3),
                   round(sum(train_result3) / len(train_result3),3),
                   round(sum(train_result4) / len(train_result4),3),
                   round(sum(test_result1) / len(test_result1),3),
                   round(sum(test_result2) / len(test_result2),3),
                   round(sum(test_result3) / len(test_result3),3),
                   round(sum(test_result4) / len(test_result4),3)])
    print([round(sum(train_result1) / len(train_result1),3),
                   round(sum(train_result2) / len(train_result2),3),
                   round(sum(train_result3) / len(train_result3),3),
                   round(sum(train_result4) / len(train_result4),3),
                   round(sum(test_result1) / len(test_result1),3),
                   round(sum(test_result2) / len(test_result2),3),
                   round(sum(test_result3) / len(test_result3),3),
                   round(sum(test_result4) / len(test_result4),3)])

#print(result)

def feature_importances():
    col = Weather.iloc[:1,cols].columns
    fi = rfc.feature_importances_
    for i in range(0, len(cols)):
        print('%s:%s' % (col[i], fi[i]))
    print(col)

#feature_importances()

# 리스트를 데이터프레임으로 변환
pd = pd.DataFrame(result, columns=['Tester', 'Cols', 'rows', 'count',
                                   'n_estimators', 'max_features',
                                   'min_samples_leaf', 'max_leaf_nodes', 'max_depth',
                                   'accuracy(train)', 'precision(train)', 'recall(train)', 'f1(train)',
                                   'accuracy(test)', 'precision(test)', 'recall(test)', 'f1(test)'])


#데이터프레임 저장
pd.to_csv('../Test004.csv')
