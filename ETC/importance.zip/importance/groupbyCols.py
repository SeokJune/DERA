import pandas as pd
import matplotlib
import matplotlib.pyplot as plt

data = pd.read_csv('./data01.csv', encoding='utf-8')
print(data.columns)
print(data[['평균기온(°C)','Rain']])
col = ['일강수량(mm)', '합계 일조시간(hr)', '평균 전운량(1/10)', '평균 상대습도(%)', 'Rain']
col1 = ['일강수량(mm)']
col2 = ['일강수량(mm)', '합계 일조시간(hr)']
col3 = ['일강수량(mm)', '합계 일조시간(hr)', '평균 전운량(1/10)']
col4 = ['일강수량(mm)', '합계 일조시간(hr)', '평균 전운량(1/10)', '평균 상대습도(%)']
data1 = data[col].groupby(col1).count()
data2 = data[col].groupby(col2).count()
data3 = data[col].groupby(col3).count()
data4 = data[col].groupby(col4).count()
print(data1)
print(data2)
print(data3)
print(data4)

data1.to_csv('./data1_01.csv', index=True, encoding='euc-kr')
data2.to_csv('./data2_01.csv', index=True, encoding='euc-kr')
data3.to_csv('./data3_01.csv', index=True, encoding='euc-kr')
data4.to_csv('./data4_01.csv', index=True, encoding='euc-kr')
